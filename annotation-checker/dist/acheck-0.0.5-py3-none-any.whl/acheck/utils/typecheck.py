def is_float(num):
    try:
        float(num)
        return True
    except ValueError:
        return False


def is_int(num):
    try:
        float(num)
        return True
    except ValueError:
        return False
